﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessGui
{
    public class game_state
    {
        public piece[,] game_board;
        public List<piece> white_pieces;
        public List<piece> black_pieces;
        int[] weights = { 1, 3, 3, 5, 9, 10000 };
        public game_state(string FEN_string) {
            this.game_board = new piece[8, 8];
            this.black_pieces = new List<piece>();
            this.white_pieces = new List<piece>();
            gen_board_from_FEN(FEN_string);
        }

        public game_state(game_state old)
        {
            this.game_board = new piece[8, 8];
            this.white_pieces = new List<piece>(old.white_pieces);
            this.black_pieces = new List<piece>(old.black_pieces);
            foreach(piece game_piece in this.white_pieces.Concat(black_pieces))
            {
                this.game_board[game_piece.row, game_piece.col] = game_piece.copy();
            }
        }

        public void gen_board_from_FEN(string FEN_string)
        {
            int row = 0;
            int col = 0;
            string digits = "0123456789";
            string p_char = "KQRBNPkqrbnp";
            foreach (char fen_char in FEN_string)
            {
                if (p_char.IndexOf(fen_char) != -1)
                {
                    piece new_pice = gen_piece(fen_char, row, col);
                    game_board[row, col] = new_pice;
                    if (new_pice.is_white)
                    {
                        this.white_pieces.Add(new_pice);
                    }
                    else { this.black_pieces.Add(new_pice); }
                    col += 1;
                }
                else if (digits.IndexOf(fen_char) != -1) {
                    for (char i = '\0'; i < fen_char - 0x30; i++)
                    {
                        game_board[row, col] = null;
                        col += 1;
                    }
                }
                else if (fen_char == '/')
                {
                    row += 1;
                    col = 0;
                }
            }
        }

        public void make_move(move the_move)
        {
            piece moved = this.game_board[the_move.start_r, the_move.start_c];
            if(moved == null) { return; }
            this.game_board[the_move.end_r, the_move.end_c] = moved;
            this.game_board[the_move.start_r, the_move.start_c] = null;
            moved.moved = true;
            moved.row = the_move.end_r;
            moved.col = the_move.end_c;
            if(the_move.capture != null)
            {
                if (the_move.capture.is_white)
                {
                    if (moved.is_white)
                    {
                        the_move.capture.row = the_move.start_r;
                        the_move.capture.col = the_move.start_c;
                    }
                    else
                    {
                        white_pieces.Remove(the_move.capture);
                    }
                }
                else
                {
                    if (moved.is_white)
                    {
                        black_pieces.Remove(the_move.capture);
                    }
                    else
                    {
                        the_move.capture.row = the_move.start_r;
                        the_move.capture.col = the_move.start_c;
                    }
                }
            }
        }

        public  game_state new_move(move the_move)
        {
            game_state new_state = new game_state(this);
            new_state.make_move(the_move);
            return new_state;
        }

        piece gen_piece(char piece_char,int row,int col)
        {
            bool white = piece_char < (char)91;
            if (!white)
            {
                piece_char -= (char)32;
            }
            if (piece_char == 'K')
            {
                return new king(white, row, col);
            }
            if (piece_char == 'R')
            {
                return new rook(white, row, col);
            }
            if (piece_char == 'B')
            {
                return new bishop(white, row, col);
            }
            if (piece_char == 'Q')
            {
                return new queen(white, row, col);
            }
            if (piece_char == 'N')
            {
                return new knight(white, row, col);
            }
            if (piece_char == 'P')
            {
                return new pawn(white, row, col);
            }
            return null;
        }

        piece find_piece(int row, int col, List<piece> s_list = null)
        {
            foreach(piece s_peace in this.white_pieces.Concat(this.black_pieces))
            {
                if((s_peace.row == row) && (s_peace.col == col))
                {
                    return s_peace;
                }
            }
            return null;
        }

        public IEnumerable<move> itter_all_moves(bool white,bool checking = false)
        {
            if (white)
            {
                foreach(piece some_piece in this.white_pieces)
                {
                    foreach(move some_move in some_piece.itter_moves(this.game_board))
                    { 
                        yield return some_move;
                    }
                }
            }
            else
            {
                foreach(piece some_piece in this.black_pieces)
                {
                    foreach(move some_move in some_piece.itter_moves(this.game_board))
                    {
                        yield return some_move;
                    }
                }
            }
        }

        private bool check_check(bool white,move a_move)
        {
            game_state next = this.new_move(a_move);
            foreach(move check_move in next.itter_all_moves(!white,false))
            {
                if(check_move.capture != null)
                {
                    if(check_move.check) { return true; }
                }
            }
            return false;
        }

        public int get_cost(bool white)
        {
            int[] black_count = { 0, 0, 0, 0, 0, 0 };
            int[] white_count = { 0, 0, 0, 0, 0, 0, 0 };
            int black_moves = 0;
            int white_moves = 0;
            int cost = 0;
            //foreach (move c_move in itter_all_moves(true)) { white_moves += 1; }
            //foreach (move c_move in itter_all_moves(false)) { black_moves += 1; }
            foreach(piece white_piece in this.white_pieces)
            {
                white_count[white_piece.weight] += 1;
            }
            foreach(piece black_piece in this.black_pieces)
            {
                black_count[black_piece.weight] += 1;
            }
            if (white)
            {
                for(int i = 0;i < 6; i++)
                {
                    cost += weights[i] * (white_count[i] - black_count[i]);
                }
                return cost + ((white_moves - black_moves) >> 1);
            }
            else
            {
                for(int i = 0;i < 6; i++)
                {
                    cost += weights[i] * (black_count[i] - white_count[i]);
                }
                return cost + ((black_moves - white_moves) >> 1);
            }
        }

        public int count_moves(int depth, game_state state = null,bool white = false)
        {
            if(state == null) { state = this; }
            int count = 0;
            if(depth == 0)
            {
                foreach(move pos_move in state.itter_all_moves(white))
                {
                    count += 1;
                }
            }
            else
            {
                foreach(move pos_move in state.itter_all_moves(white))
                {
                    game_state child = state.new_move(pos_move);
                    count += count_moves(depth - 1, child, !white);
                }
            }
            return count;
        }
    }
}
