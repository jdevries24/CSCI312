﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChessGui
{
    
    public partial class Form1 : Form
    {
        Dictionary<char, string> FEN_lookup = new Dictionary<char, string>();
        Button[,] chess_board_buttons = new Button[8, 8];
        move[,] move_index = new move[8, 8];
        game_state my_main;
        List<int[]> pos_moves;
        AI black_ai;
        AI white_ai;
        char[,] chess_board_state = new char[8, 8];
        public bool machine_turn = false;
        public bool white_turn = true;
        public bool piece_selected = false;
        int sp_row = 0;
        int sp_col = 0;

        public Form1()
        {
            InitializeComponent();
            this.FEN_lookup.Add('K',"\u2654");
            this.FEN_lookup.Add('Q', "\u2655");
            this.FEN_lookup.Add('R', "\u2656");
            this.FEN_lookup.Add('B', "\u2657");
            this.FEN_lookup.Add('N', "\u2658");
            this.FEN_lookup.Add('P', "\u2659");
            this.FEN_lookup.Add('k', "\u265A");
            this.FEN_lookup.Add('q', "\u265B");
            this.FEN_lookup.Add('r', "\u265C");
            this.FEN_lookup.Add('b', "\u265D");
            this.FEN_lookup.Add('n', "\u265E");
            this.FEN_lookup.Add('p', "\u265F");
            this.init_board();
            my_main = new game_state("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR");
            this.decode_FEN("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR");
            black_ai = new AI();
            white_ai = new AI();
            white_ai.MAXING_player = true;
        }

        private void init_board()
        {
            for (int i = 0; i < 8; i++)
            {
                Label row_number = new Label();
                row_number.Size = new System.Drawing.Size(20, 20);
                row_number.Text = (i).ToString();
                row_number.Location = new System.Drawing.Point(50, 50 + (100 * i));
                this.Controls.Add(row_number);
                for (int j = 0; j < 8; j++)
                {
                    Button chess_square = new Button();
                    chess_square.Size = new System.Drawing.Size(100, 100);
                    chess_square.Location = new System.Drawing.Point(100 + (100 * j), 50 + (100 * i));
                    chess_square.Font = new Font("Arial Narrow", 48);
                    chess_square.Tag = (i << 4) | j;
                    chess_square.Click += delegate(object sender, EventArgs e) { on_click(sender, e); };
                    this.chess_board_buttons[i, j] = chess_square;
                    chess_square.Text = "";
                    this.Controls.Add(chess_square);
                }
            }
            string letters = "abcdefgh";
            for (int j = 0; j < 8; j++)
            {
                Label col_number = new Label();
                col_number.Size = new System.Drawing.Size(100, 100);
                col_number.Text = j.ToString();
                col_number.Location = new System.Drawing.Point(120 + (100 * j), 900);
                this.Controls.Add(col_number);
            }
            this.checker_board();
        }

        public void decode_FEN(string fen_str)
        {
            int row = 0;
            int col = 0;
            string digits = "012345678";
            string pieces = "pnbrqkPNBRQK";
            foreach(char FEN_Char in fen_str)
            {
                if(pieces.IndexOf(FEN_Char) != -1)
                {
                    this.chess_board_buttons[row, col].Text = this.FEN_lookup[FEN_Char];
                    col += 1;
                }
                else if(digits.IndexOf(FEN_Char) != -1)
                {
                    for (int i = 0; i < (int)FEN_Char - 0x30; i++)
                    {
                        this.chess_board_buttons[row, col].Text = " ";
                        col += 1;
                    }
                }
                else if(FEN_Char == '/')
                {
                    row += 1;
                    col = 0;
                }
            }
        }

        public void Log(string message)
        {
            this.Log_box.Text += message + '\n';
        }

        public void checker_board()
        {
            int count = 0;
            bool peach = false;
            foreach(Button board_square in this.chess_board_buttons)
            {
                if (count % 8 != 0)
                {
                    peach = !peach;
                }
                count += 1;
                if (peach){
                    board_square.BackColor = Color.Goldenrod;
                }
                else
                {
                    board_square.BackColor = Color.Wheat;
                }
            }
        }

        public void index_moves(List<move> move_list)
        {
            this.move_index = new move[8, 8];
            for(int i = 0;i < 8; i++)
            {
                for(int j = 0;j < 8; j++)
                {
                    this.move_index[i, j] = null;
                }
            }
            foreach (move a_move in move_list)
            {
                this.move_index[a_move.end_r, a_move.end_c] = a_move;
                this.chess_board_buttons[a_move.end_r, a_move.end_c].BackColor = Color.Yellow;
                if(a_move.capture != null)
                {
                    this.chess_board_buttons[a_move.end_r, a_move.end_c].BackColor = Color.Red;
                }
            }
        }

        public void random_play()
        {
                var rad = new Random();
                move next = null;
                List<move> posible = new List<move>();
                if (white_turn)
                {
                    foreach(piece p in my_main.white_pieces)
                    {
                        posible = posible.Concat(p.get_moves(my_main.game_board)).ToList();
                    }
                }
                else
                {
                    foreach(piece p in my_main.black_pieces)
                    {
                        posible = posible.Concat(p.get_moves(my_main.game_board)).ToList();
                    }
                }
                int index = rad.Next(posible.Count);
                my_main.make_move(posible[index]);
                next = posible[index];
                string move_char = chess_board_buttons[next.start_r, next.start_c].Text;
                chess_board_buttons[next.start_r, next.start_c].Text = " ";
                chess_board_buttons[next.end_r, next.end_c].Text = move_char;
            white_turn = !white_turn;
        }

        public void on_click(object sender,EventArgs e)
        {
            this.checker_board();
            Button send = (Button)sender;
            int send_id = (int)send.Tag;
            int row = send_id >> 4;
            int col = send_id & 0b1111;
            if (this.piece_selected)
            {
                if (move_index[row, col] != null)
                {
                    move a_move = move_index[row, col];
                    string moved_char = chess_board_buttons[a_move.start_r,a_move.start_c].Text;
                    chess_board_buttons[a_move.start_r, a_move.start_c].Text = " ";
                    chess_board_buttons[a_move.end_r, a_move.end_c].Text = moved_char;
                    my_main.make_move(a_move);
                }
                this.piece_selected = false;
                Log("Cost of pos is: " + my_main.get_cost(true).ToString());
            }
            else
            {
                piece playing_piece = my_main.game_board[row, col];
                if(playing_piece == null)
                {
                    return;
                }
                List<move> move_list = playing_piece.get_moves(my_main.game_board);
                index_moves(move_list);
                this.piece_selected = true;
                chess_board_buttons[row, col].BackColor = Color.Gold;
            }
        }

        private void display_move(move a_move)
        {
            this.checker_board();
            string moved_char = chess_board_buttons[a_move.start_r, a_move.start_c].Text;
            chess_board_buttons[a_move.start_r, a_move.start_c].Text = " ";
            chess_board_buttons[a_move.end_r, a_move.end_c].Text = moved_char;
            my_main.make_move(a_move);
        }

        private void Utill_button_Click(object sender, EventArgs e)
        {
            move a_move = black_ai.get_move(my_main);
            display_move(a_move);
            Log("Black cost is " + my_main.get_cost(false).ToString());
        }

        private void log_move(move a_move)
        {
            string start_pos = a_move.start_r.ToString() + " . " + a_move.start_c.ToString();
            string end_pos = a_move.end_r.ToString() + " . " + a_move.end_c.ToString();
            Log(start_pos + "\t" + end_pos);
        }

        private void Utill_2_Click(object sender, EventArgs e)
        {
            move a_move = white_ai.get_move(my_main);
            display_move(a_move);
            Log("White cost is " + my_main.get_cost(true).ToString());
        }
    }
}
