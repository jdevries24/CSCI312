﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chess
{
    public class AI
    {
        public static int DEPTH = 4;
        public static bool RUNNING = false;
        public static bool STOP = false;

        public static move_t MiniMaxAB(ChessBoard board, Player turn)
        {
             RUNNING = true; // we've started running
             STOP = false; // no interupt command sent
             //this method is like the maximizing method of alpha beta prunning
             //including tracking the alpha value 
             //however this method also trakes the move node associated with
             //the best value. 
             Player opponent = (turn == Player.BLACK ? Player.WHITE : Player.BLACK);
             move_t best_move = new move_t(new position_t(0,0),new position_t(0,0));//init move to null
             int value = int.MinValue;
             int new_value = int.MinValue;
             int alpha = int.MinValue;
             foreach (move_t move in p_get_moves(board, turn))
             {
                 ChessBoard node = LegalMoveSet.move(board, move);
                 new_value = Alpha_Beta_Min_Max(node, opponent, turn, DEPTH - 1, alpha, int.MaxValue);
                 if (new_value > value)
                 {
                     best_move = move;
                     value = new_value;
                 }
                 alpha = Math.Max(alpha, value);
                 if (STOP)
                 {
                     break;
                 }
             }
             RUNNING = false;
             STOP = true;
             return best_move; 
        }

        public static int Alpha_Beta_Min_Max(ChessBoard board, Player turn,Player maxer, int depth, int alpha, int beta)
        {
            Player oponent = (turn == Player.BLACK ? Player.WHITE : Player.BLACK);//first off we need to know the other opennent
            if (depth <= 0)//if we are at the depth limit then return the huristic value for the maxing player
            {
                return board.fitness(maxer);
            }
            if (turn == maxer)
            {
                //if we are the maxing player we want to find the maximum branch from the current node
                int value = int.MinValue;//unfortentaly there is no infinity int but this is close enogh
                foreach (move_t move in AI.p_get_moves(board, turn))
                {//iterate through all the nodes 
                    ChessBoard node = LegalMoveSet.move(board, move);//make the move
                    //then deteman if this move is better then our current value. 
                    value = Math.Max(value, Alpha_Beta_Min_Max(node, oponent,maxer, depth - 1, alpha, beta));
                    //if our value is bigger then the aboves current minimum value then 
                    //we know that our node will not be chosen no matter what therefor 
                    //we dont need to evaluate the rest of our branches
                    if (value >= beta)
                    {
                        return value;
                    }
                    alpha = Math.Max(value, alpha);//we also want to track our current maximum value for the minning type
                }
                //if the value remained at -inf then we had no nodes therefore where a terminal node and we should
                //return our fitness
                if(value == int.MinValue) { return board.fitness(maxer); }
                return value;
            }
            else
            {
                //for minimizing the algorith is more or less the flip of maximizing.
                //track the current minimum value we can. If our minimum value is lower
                //then our parrents maximum value then we won't be chosen so we can be skipped
                int value = int.MaxValue;
                foreach (move_t move in AI.p_get_moves(board, turn))
                {
                    ChessBoard node = LegalMoveSet.move(board, move);
                    value = Math.Min(value, Alpha_Beta_Min_Max(node, oponent,maxer, depth - 1, alpha, beta));
                    if (value <= alpha)
                    {
                        return value;
                    }
                    beta = Math.Min(value, beta);
                }
                if(value == int.MaxValue) { return board.fitness(maxer); }
                return value;
            }
        }


        public  static IEnumerable<move_t> p_get_moves(ChessBoard board, Player play)
        {
            //method to enumerate through posible moves the dictonary method of player moves is somwhat combersom
            //for the main min maxing body 
            Dictionary<position_t, List<position_t>> move_dict = LegalMoveSet.getPlayerMoves(board, play);
            List<move_t> non_take_list = new List<move_t>();
            foreach (KeyValuePair<position_t, List<position_t>> dict_pair in move_dict)
            {
                position_t start = dict_pair.Key;
                foreach (position_t end in dict_pair.Value)
                {
                    //however there is a twist. For Alpha beta prunning nodes with more extream lower or 
                    //higher values are more likely to lead to future prenning. Therefore it is best if
                    //our algorith evaluates branches with taken peaces first.
                    if (board.Grid[end.number][end.letter].piece != Piece.NONE)
                    {
                        yield return new move_t(start, end);
                    }
                }
            }
            foreach (KeyValuePair<position_t, List<position_t>> dict_pair in move_dict)
            {
                position_t start = dict_pair.Key;
                foreach (position_t end in dict_pair.Value)
                {
                    //then return nodes without pices taken
                    if (board.Grid[end.number][end.letter].piece == Piece.NONE)
                    {
                        yield return new move_t(start, end);
                    }
                }
            }
        }
    }
}
