﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessGui
{
    public class move
    {
        public int start_r;
        public int start_c;
        public int end_r;
        public int end_c;
        public bool check;
        public piece capture;
        public move(int start_row, int start_col, int end_row, int end_col, piece capture = null)
        {
            this.start_r = start_row;
            this.start_c = start_col;
            this.end_r = end_row;
            this.end_c = end_col;
            this.capture = capture;
            if (this.capture != null)
            {
                this.check = (capture.name == 'k') || (capture.name == 'K');
            }
            else { this.check = false; }
        }
    }

    public class piece
    {
        public bool is_white;
        public bool moved;
        public int row;
        public int col;
        public char name;
        public int weight;

        public piece()
        {
            this.is_white = true;
            this.moved = false;
            this.row = 0;
            this.col = 0;
        }
        public piece(bool white, int row, int col)
        {
            this.is_white = white;
            this.row = row;
            this.col = col;
        }

        public piece(piece old)
        {
            this.row = old.row;
            this.moved = old.moved;
            this.col = old.col;
            this.is_white = old.is_white;
        }

        public virtual piece copy()
        {
            return new piece(this.is_white, this.row, this.col);
        }


        public bool in_bounds(int new_row, int new_col)
        {
            return ((new_row < 8) && (new_row >= 0) && (new_col >= 0) && (new_col < 8));
        }

        public virtual List<move> get_moves(piece[,] game_matrix)
        {
            return null;
        }

        public virtual IEnumerable<move> itter_moves(piece[,] game_matrix)
        {
            yield return null;
        }

        public bool is_friendly(char unknown_piece)
        {
            if (this.is_white)
            {
                return unknown_piece < 91;
            }
            else
            {
                return unknown_piece > 96; 
            }
        }

        public void move(int new_row,int new_col)
        {
            this.moved = false;
            this.row = new_row;
            this.col = new_col;
        }
    }

    public class pawn : piece
    {
        public pawn(bool white,int row,int col) : base(white, row, col)
        {
            this.name = 'p';
            this.weight = 0;
        }


        public pawn(pawn old)
        {
            this.name = 'p';
            this.weight = 0;
            this.row = old.row;
            this.moved = old.moved;
            this.col = old.col;
            this.is_white = old.is_white;
        }

        public override piece copy()
        {
            return new pawn(this);
        }

        public override IEnumerable<move> itter_moves(piece[,] game_matrix) {
            int step_dir = this.is_white ? -1 : 1;
            if(in_bounds(this.row + step_dir,this.col + 1) && (game_matrix[this.row + step_dir,this.col + 1] != null)){
                if (game_matrix[this.row + step_dir,this.col + 1].is_white != this.is_white){
                    yield return new move(this.row, this.col, this.row + step_dir, this.col + 1,game_matrix[this.row + step_dir,this.col + 1]);
                }
            }
            if(in_bounds(this.row + step_dir,this.col - 1) && (game_matrix[this.row + step_dir,this.col - 1] != null))
            {
                if(game_matrix[this.row + step_dir,this.col - 1].is_white != this.is_white)
                {
                    yield return new move(this.row, this.col, this.row + step_dir, this.col - 1,game_matrix[this.row + step_dir,this.col - 1]);
                }
            }
            if (in_bounds(this.row + step_dir, this.col) && (game_matrix[this.row + step_dir,this.col] == null))
            {
                yield return new move(this.row, this.col, this.row + step_dir, this.col);
                if((!this.moved) &&(game_matrix[this.row + (2*step_dir),this.col] == null))
                {
                    yield return new move(this.row, this.col, this.row + (2*step_dir),this.col);
                }
            }
        }

        public override List<move> get_moves(piece[,] game_matrix)
        {
            return itter_moves(game_matrix).ToList();
        }
    }

    public class rook : piece
    {
        public int[] row_dirs = { -1, 0, 1, 0 };
        public int[] col_dirs = { 0, -1, 0, 1 };
        public int move_combos = 4;

        public rook(bool white,int row,int col) : base(white, row, col)
        {
            this.name = 'r';
            this.weight = 3;
        }

        public rook(rook old)
        {
            this.name = 'r';
            this.weight = 3;
            this.row = old.row;
            this.moved = old.moved;
            this.col = old.col;
            this.is_white = old.is_white;
        }

        public override piece copy()
        {
            return new rook(this);
        }

        public override IEnumerable<move> itter_moves(piece[,] game_matrix)
        {
            for(int i = 0;i < this.move_combos; i++)
            {
                int row_step = this.row_dirs[i];
                int col_step = this.col_dirs[i];
                int w_row = this.row;
                int w_col = this.col;
                while(in_bounds(w_row + row_step,w_col + col_step)){
                    w_row += row_step;
                    w_col += col_step;
                    if(game_matrix[w_row,w_col] == null)
                    {
                        yield return(new move(this.row, this.col, w_row, w_col));
                    }
                    else
                    {
                        if (game_matrix[w_row, w_col].is_white == this.is_white)
                        {
                            break;
                        }
                        else
                        {
                            yield return(new move(this.row, this.col, w_row, w_col, game_matrix[w_row, w_col]));
                            break;
                        }
                    }
                }
            }
        }
        public override List<move> get_moves(piece[,] game_matrix)
        {
            return itter_moves(game_matrix).ToList();
        }

    }

    public class bishop : piece {

        int[] row_dirs = { 1, 1, -1, -1 };
        int[] col_dirs = { 1, -1, 1, -1 };
        int move_combos = 4;

        public bishop(bool white, int row, int col) : base(white, row, col) {
            this.name = 'b';
            this.weight = 2;
        }

        public bishop(bishop old)
        {
            this.name = 'b';
            this.weight = 2;
            this.row = old.row;
            this.moved = old.moved;
            this.col = old.col;
            this.is_white = old.is_white;
        }

        public override piece copy()
        {
            return new bishop(this);
        }

        public override IEnumerable<move> itter_moves(piece[,] game_matrix)
        {
            List<move> move_list = new List<move>();
            for (int i = 0; i < this.move_combos; i++)
            {
                int row_step = this.row_dirs[i];
                int col_step = this.col_dirs[i];
                int w_row = this.row;
                int w_col = this.col;
                while (in_bounds(w_row + row_step, w_col + col_step))
                {
                    w_row += row_step;
                    w_col += col_step;
                    if (game_matrix[w_row, w_col] == null)
                    {
                        yield return(new move(this.row, this.col, w_row, w_col));
                    }
                    else
                    {
                        if (game_matrix[w_row, w_col].is_white == this.is_white)
                        {
                            break;
                        }
                        else
                        {
                            yield return(new move(this.row, this.col, w_row, w_col, game_matrix[w_row, w_col]));
                            break;
                        }
                    }
                }
            }
        }
        public override List<move> get_moves(piece[,] game_matrix)
        {
            return itter_moves(game_matrix).ToList();
        }

    }

    public class queen : piece
    {
        public int[] row_dirs = { 1, 1, 1, 0, -1, -1, -1, 0 };
        public int[] col_dirs = { 1, 0, -1, -1, -1, 0, 1, 1 };
        public int move_combos = 8;

        public queen(bool white, int row, int col) : base(white, row, col)
        {
            this.name = 'q';
            this.weight = 4;
        }

        public queen(queen old)
        {
            this.name = 'q';
            this.weight = 4;
            this.row = old.row;
            this.moved = old.moved;
            this.col = old.col;
            this.is_white = old.is_white;
        }

        public override piece copy()
        {
            return new queen(this);
        }

        public override IEnumerable<move> itter_moves(piece[,] game_matrix)
        {
            List<move> move_list = new List<move>();
            for (int i = 0; i < this.move_combos; i++)
            {
                int row_step = this.row_dirs[i];
                int col_step = this.col_dirs[i];
                int w_row = this.row;
                int w_col = this.col;
                while (in_bounds(w_row + row_step, w_col + col_step))
                {
                    w_row += row_step;
                    w_col += col_step;
                    if (game_matrix[w_row, w_col] == null)
                    {
                        yield return(new move(this.row, this.col, w_row, w_col));
                    }
                    else
                    {
                        if (game_matrix[w_row, w_col].is_white == this.is_white)
                        {
                            break;
                        }
                        else
                        {
                            yield return(new move(this.row, this.col, w_row, w_col, game_matrix[w_row, w_col]));
                            break;
                        }
                    }
                }
            }
        }
        public override List<move> get_moves(piece[,] game_matrix)
        {
            return itter_moves(game_matrix).ToList();
        }
    }

    public class king : piece
    {
        int[] row_dirs = { 1, 1, 1, 0, -1, -1, -1, 0 };
        int[] col_dirs = { 1, 0, -1, -1, -1 ,0, 1, 1 };
        int move_combos = 8;
        public king(bool white,int row,int col) : base(white, row, col)
        {
            this.name = 'k';
            this.weight = 5;
        }

        public king(king old)
        {
            this.name = 'k';
            this.weight = 5;
            this.row = old.row;
            this.moved = old.moved;
            this.col = old.col;
            this.is_white = old.is_white;
        }

        public override piece copy()
        {
            return new king(this);
        }

        public override IEnumerable<move> itter_moves(piece[,] game_matrix)
        {
            List<move> move_list = new List<move>();
            for(int i = 0;i < this.move_combos; i++)
            {
                int row_dir = this.row_dirs[i];
                int col_dir = this.col_dirs[i];
                if (in_bounds(this.row + row_dir, this.col + col_dir))
                {
                    if(game_matrix[this.row + row_dir,this.col + col_dir] == null)
                    {
                        yield return(new move(this.row, this.col, this.row + row_dir, this.col + col_dir));
                    }
                    else if(game_matrix[this.row + row_dir,this.col + col_dir].is_white != this.is_white)
                    {
                        yield return(new move(this.row, this.col, this.row + row_dir, this.col + col_dir, game_matrix[this.row + row_dir, this.col + col_dir]));
                    }
                }
            }
        }
        public override List<move> get_moves(piece[,] game_matrix)
        {
            return itter_moves(game_matrix).ToList();
        }
    }

    public class knight : piece
    {
        public int[] row_dirs = { 1, 2, 2, 1, -1, -2, -2, -1 };
        public int[] col_dirs = { -2, -1, 1, 2, 2, 1, -1, -2 };
        int move_combos = 8;

        public knight(bool white, int row, int col) : base(white, row, col)
        {
            this.name = 'n';
            this.weight = 1;
        }

        public knight(knight old)
        {
            this.name = 'n';
            this.weight = 1;
            this.row = old.row;
            this.moved = old.moved;
            this.col = old.col;
            this.is_white = old.is_white;
        }

        public override piece copy()
        {
            return new knight(this);
        }

        public override IEnumerable<move> itter_moves(piece[,] game_matrix)
        {
            List<move> move_list = new List<move>();
            for (int i = 0; i < this.move_combos; i++)
            {
                int row_dir = this.row_dirs[i];
                int col_dir = this.col_dirs[i];
                if (in_bounds(this.row + row_dir, this.col + col_dir))
                {
                    if (game_matrix[this.row + row_dir, this.col + col_dir] == null)
                    {
                        yield return(new move(this.row, this.col, this.row + row_dir, this.col + col_dir));
                    }
                    else if ((game_matrix[this.row + row_dir, this.col + col_dir].is_white) != this.is_white)
                    {
                        yield return(new move(this.row, this.col, this.row + row_dir, this.col + col_dir, game_matrix[this.row + row_dir, this.col + col_dir]));
                    }
                }
            }
        }
        public override List<move> get_moves(piece[,] game_matrix)
        {
            return itter_moves(game_matrix).ToList();
        }
    }
}
