﻿namespace ChessGui
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Log_box = new System.Windows.Forms.RichTextBox();
            this.Utill_button = new System.Windows.Forms.Button();
            this.Utill_2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Log_box
            // 
            this.Log_box.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Log_box.Location = new System.Drawing.Point(918, 12);
            this.Log_box.Name = "Log_box";
            this.Log_box.Size = new System.Drawing.Size(319, 576);
            this.Log_box.TabIndex = 0;
            this.Log_box.Text = "";
            // 
            // Utill_button
            // 
            this.Utill_button.Location = new System.Drawing.Point(918, 594);
            this.Utill_button.Name = "Utill_button";
            this.Utill_button.Size = new System.Drawing.Size(85, 23);
            this.Utill_button.TabIndex = 1;
            this.Utill_button.Text = "Play_Black";
            this.Utill_button.UseVisualStyleBackColor = true;
            this.Utill_button.Click += new System.EventHandler(this.Utill_button_Click);
            // 
            // Utill_2
            // 
            this.Utill_2.Location = new System.Drawing.Point(1009, 594);
            this.Utill_2.Name = "Utill_2";
            this.Utill_2.Size = new System.Drawing.Size(81, 23);
            this.Utill_2.TabIndex = 2;
            this.Utill_2.Text = "Play_White";
            this.Utill_2.UseVisualStyleBackColor = true;
            this.Utill_2.Click += new System.EventHandler(this.Utill_2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1249, 875);
            this.Controls.Add(this.Utill_2);
            this.Controls.Add(this.Utill_button);
            this.Controls.Add(this.Log_box);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox Log_box;
        private System.Windows.Forms.Button Utill_button;
        private System.Windows.Forms.Button Utill_2;
    }
}

