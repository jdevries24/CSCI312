﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chess
{
    public class AI
    {
        public static int DEPTH = 4;
        public static bool RUNNING = false;
        public static bool STOP = false;
        private static Player MAX = Player.BLACK;
        private static Player MIN = Player.WHITE;

        public static move_t MiniMaxAB(ChessBoard board, Player turn)
        {
            RUNNING = true; // we've started running
            STOP = false; // no interupt command sent
            MAX = turn; // who is maximizing
            MIN = (turn == Player.WHITE ? Player.BLACK : Player.WHITE);
            //TBD: gather all possible moves;
            //storing best result from each round;
            //ForEach implements recursion logic;
            //decide the best move.           
            move_t best_move = new move_t(new position_t(0,0),new position_t(0,0));
            int best_value = int.MinValue;
            foreach (KeyValuePair<position_t, List<position_t>> move_pair in LegalMoveSet.getPlayerMoves(board, turn))
            {
                position_t start = move_pair.Key;
                foreach(position_t end in move_pair.Value)
                {
                    move_t move = new move_t(start, end);
                    int new_value = mimaab(LegalMoveSet.move(board, move), MIN, DEPTH, int.MinValue, int.MaxValue);
                    if(new_value > best_value)
                    {
                        best_value = new_value;
                        best_move = move;
                    }
                    if (STOP)
                    {
                        RUNNING = false;
                        return best_move;
                        
                    }
                }
            }
            RUNNING = false;
            return best_move;
        }

        private static int mimaab(ChessBoard board, Player turn, int depth, int alpha, int beta)
        {
            Player oponent = (turn == Player.BLACK ? Player.WHITE : Player.BLACK);
            if(depth == 0)
            {
                return board.fitness(MAX);
            }
            if(LegalMoveSet.getPlayerMoves(board,turn).Count == 0)
            {
                return board.fitness(MAX);
            }
            if(turn == MAX)
            {
                int value = int.MinValue;
                foreach (move_t move in AI.get_moves(board, turn))
                {
                    ChessBoard node = LegalMoveSet.move(board, move);
                    value = Math.Max(value, mimaab(node, oponent, depth - 1, alpha, beta));
                    alpha = Math.Max(value, alpha);
                    if(value >= beta)
                    {
                        return value;
                    }
                }
                return value;
            }
            else
            {
                int value = int.MaxValue;
                foreach(move_t move in AI.get_moves(board, turn))
                {
                    ChessBoard node = LegalMoveSet.move(board, move);
                    value = Math.Min(value, mimaab(node, oponent, depth - 1, alpha, beta));
                    beta = Math.Min(value, beta);
                    if(value <= beta)
                    {
                        return value;
                    }
                }
                return value;
            }
        }

        private static int get_max(int a,int b)
        {
            if(a > b) { return a; }
            else { return b; }
        }

        private static int get_min(int a,int b)
        {
            if (a < b) { return a; }
            else { return b; }
        }

        private static IEnumerable<move_t> get_moves(ChessBoard board,Player play)
        {
            Dictionary<position_t, List<position_t>> move_dict = LegalMoveSet.getPlayerMoves(board, play);
            List<move_t> move_list = new List<move_t>();
            foreach (KeyValuePair<position_t, List<position_t>> dict_pair in move_dict)
            {
                position_t start = dict_pair.Key;
                foreach(position_t end in dict_pair.Value)
                {
                    yield return new move_t(start, end);
                }
            }
        }
    }
}
