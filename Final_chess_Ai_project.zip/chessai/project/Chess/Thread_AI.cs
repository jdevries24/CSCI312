﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Linq;
using System.Text;

namespace Chess
{
    class Thread_AI
    {
        static List<move_t> move_list;
        static move_t best_move;
        static Player MAXER;
        static Player MINIR;
        static ChessBoard our_board;
        static int alpha;
        static int value;
        static int semiphore;
        private static Mutex mut = new Mutex();
        static public bool STOP = false;
        static public int DEPTH = 3;
        static public bool RUNNING = false;
        /*this class allows for the top branches to be evaluated with multiple threads.
         * this also allows for the computer to dedicate all cores to evalueation. It does
         * help quite a bit with preformace however it makes my labtop sound like a jet engine*/

        public static move_t MiniMaxAB(ChessBoard board,Player turn)
        {
            RUNNING = true;
            STOP = false;
            our_board = board;//save the board as a class varible for threads to get easy acsses
            move_list = new List<move_t>();
            foreach(move_t move in AI.p_get_moves(board, turn)) { move_list.Add(move); }//init the move list as an actual 
            //move list
            best_move = move_list[0]; //and set the best_move as the first value
            MAXER = turn;
            MINIR = (turn == Player.BLACK ? Player.WHITE : Player.BLACK);
            alpha = int.MinValue;//set our alpha and value to -inf
            value = int.MinValue;
            //set off as much threads as there are porcessors
            semiphore = 0;
            for(int i= 0;i < (Environment.ProcessorCount); i++)
            {
                Thread new_thread = new Thread(new ThreadStart(Worker));
                new_thread.Start();
            }
            while (true)
            {
                //now a supervisor thread. every 100 ms check if the move_list has no 
                //more moves left to evalueate. or if a stop call has been made
                Thread.Sleep(100);
                mut.WaitOne();//move list may be modified and is a shared resorce
                if (STOP)
                {
                    move_list = new List<move_t>();
                }
                //if our list has no more moves left and all the threads
                //have reported back with values then we can brake.
                if((move_list.Count == 0) && (semiphore == 0))
                {
                    mut.ReleaseMutex();
                    break;
                }
                mut.ReleaseMutex();
            }
            RUNNING = false;
            return best_move;
        }

        static void Worker()
        {
            mut.WaitOne();
            semiphore += 1;//the semiphore tracks howmuch threads are still running
            mut.ReleaseMutex();
            while (true)
            {
                mut.WaitOne();
                if(move_list.Count == 0)
                {
                    //if there are no more moves to do then decress the semiphore 
                    semiphore -= 1;
                    mut.ReleaseMutex();
                    //and exit
                    return;
                }
                //dequeu the next move 
                move_t my_move = move_list[0];
                move_list.RemoveAt(0);
                ChessBoard my_state = LegalMoveSet.move(our_board, my_move);
                int my_alpha = alpha;//store alpha and board states inside local vars to prevent confics or race conditions
                mut.ReleaseMutex();
                //release the Mutex then we can use the standard AI to move down the rest of the way for the min maxing
                int test = AI.Alpha_Beta_Min_Max(my_state, MINIR,MAXER, DEPTH - 1,my_alpha, int.MaxValue);
                mut.WaitOne();
                //then test our value and set best moves and values apropratly
                if (test > value)
                {
                    value = test;
                    best_move = my_move;
                }
                //oh and alpha
                alpha = Math.Max(alpha, value);
                mut.ReleaseMutex();
            }
        }
    }
}
