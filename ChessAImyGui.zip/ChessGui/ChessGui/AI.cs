﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessGui
{
    class AI
    {
        public bool MAXING_player = false;
        int DEPTH = 3;

        public move get_move(game_state state)
        {
            int value = int.MinValue;
            List<move> best_moves = new List<move>();
            foreach(move test_move in state.itter_all_moves(MAXING_player))
            {
                game_state test_state = state.new_move(test_move);
                int new_value = alpha_beta_search(test_state,DEPTH, !MAXING_player,int.MinValue,int.MaxValue);
                //int new_value = min_max(test_state, DEPTH, !MAXING_player);
                if (new_value > value)
                {
                    best_moves = new List<move>();
                    best_moves.Add(test_move);
                    value = new_value;
                }
                if(new_value == value)
                {
                    best_moves.Add(test_move);
                }
            }
            Random rand = new Random();
            int best_index = rand.Next(0, best_moves.Count());
            return best_moves[best_index];
        }

        public int min_max(game_state state,int depth,bool player)
        {
            if(depth == 0)
            {
                return state.get_cost(MAXING_player);
            }
            if(player == MAXING_player)
            {
                int value = int.MinValue;
                foreach(move test_move in state.itter_all_moves(player))
                {
                    value = Math.Max(min_max(state.new_move(test_move), depth - 1, !player), value);
                }
                return value;
            }
            else
            {
                int value = int.MaxValue;
                foreach(move test_move in state.itter_all_moves(player))
                {
                    value = Math.Min(min_max(state.new_move(test_move), depth - 1, !player), value);
                }
                return value;
            }
        }

        public int alpha_beta_search(game_state state, int depth, bool player, int alpha, int beta)
        {
            if (depth == 0)
            {
                return state.get_cost(MAXING_player);
            }
            if (player == MAXING_player)
            {
                int value = int.MinValue;
                foreach(move pos_move in state.itter_all_moves(player))
                {
                    game_state child = state.new_move(pos_move);
                    value = Math.Max(alpha_beta_search(child, depth - 1,!player, alpha, beta), value);
                    alpha = Math.Max(value, alpha);
                    if(value >= beta)
                    {
                        break;
                    }
                }
                return value;
            }
            else
            {
                int value = int.MaxValue;
                foreach(move pos_move in state.itter_all_moves(player))
                {
                    game_state child = state.new_move(pos_move);
                    value = Math.Min(alpha_beta_search(child, depth - 1, !player, alpha, beta), value);
                    beta = Math.Min(value, beta);
                    if(alpha >= value)
                    {
                        break;
                    }
                }
                return value;
            }
        }
    }
}